package com.riccardo.rest.api.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.ExposesResourceFor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.riccardo.rest.api.domain.Product;
import com.riccardo.rest.api.entity.ProductEntity;
import com.riccardo.rest.api.mapper.DomainToEntityMapping;
import com.riccardo.rest.api.mapper.DomainToRessourceMapping;
import com.riccardo.rest.api.mapper.EntityToDomainMapping;
import com.riccardo.rest.api.resource.ProductResource;
import com.riccardo.rest.api.service.IProductService;

@CrossOrigin(origins = "*")
@RestController
@ExposesResourceFor(Product.class)
@RequestMapping(value = "/product", produces = "application/json")
public class ProductController {
	
	/*@Autowired
	private OrderRepository repository;*/
	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private DomainToRessourceMapping domainToRessourceMapping;

	@Autowired
	private EntityToDomainMapping entityTODomainMapping;
	
	@Autowired
	private DomainToEntityMapping  domainToEntityMapping;
	
	//private static Logger logger = Logger.getLogger(ProductController.class);
	
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<Collection<ProductResource>> findAllProducts() {
		
		//repository.findAll();
		List<ProductEntity> productentities = productService.getAllProducts();
		
		Collection<Product> products = entityTODomainMapping.toDomainCollection(productentities);
		
		return new ResponseEntity<>(domainToRessourceMapping.toResourceCollection(products), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<Void> addProduct(@RequestBody Product product, UriComponentsBuilder builder) {
		
		HttpHeaders headers = new HttpHeaders();
		
		try {

			productService.addProduct(domainToEntityMapping.toEntity(product));
            headers.setLocation(builder.path("/product/{id}").buildAndExpand(product.getId()).toUri());
			
		} catch(Exception e) {
			//logger.debug("An error occured while adding a new product " + e.getMessage());
		}
		
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<ProductResource> findProductById(@PathVariable int id) {
		
		ProductResource productRessource = null;
		
		try {
			
			ProductEntity productEntity = productService.getProductById(id);
			Product productDomain = entityTODomainMapping.toDomain(productEntity);
			productRessource = domainToRessourceMapping.toResource(productDomain);
		
		}catch (Exception e) {
			//logger.debug("An error occured while retrieving the product with id " +id + " with the following error message" + e.getMessage());
		}
		
		if(productRessource!=null) {
			return new ResponseEntity<ProductResource>(productRessource, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteProduct(@PathVariable int id) {
		
		HttpStatus responseStatus=null;
		try {
			
			//check if the product exists before deleting
			if(productService.getProductById(id)!=null) {
				
				productService.deleteProduct(id);
				responseStatus = HttpStatus.NO_CONTENT;
				
			} else {
				responseStatus = HttpStatus.NOT_FOUND;
			}
			
		} catch (Exception e) {
			//logger.debug("An error occured while deleting the product with id " +id + " with the following error message" + e.getMessage());
		}
		
		return new ResponseEntity<>(responseStatus);
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.PUT, consumes = "application/json")
	public ResponseEntity<ProductResource> updateOrder(@RequestBody Product updatedProduct) {
		
		HttpStatus responseStatus=null;
		ProductResource updatedProductRessource = null;
		try {
			
			//check if the product exists before deleting
			if(productService.getProductById(updatedProduct.getId())!=null) {
				ProductEntity productEntity = domainToEntityMapping.toEntity(updatedProduct);
				productService.updateProduct(productEntity);
				updatedProductRessource = domainToRessourceMapping.toResource(updatedProduct);
				
				responseStatus = HttpStatus.OK;
			} else {
				responseStatus = HttpStatus.NOT_FOUND;
			}
			
		} catch(Exception e) {
			//logger.debug("An error occured while updating the product with the following error message" + e.getMessage());
		}
		
		return new ResponseEntity<ProductResource>(updatedProductRessource, responseStatus);
		
		
	}
}
