/**
 * 
 */
package com.riccardo.rest.api.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.riccardo.rest.api.entity.ProductEntity;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author m_de
 *
 */
@Transactional
@Repository
public class ProductDao implements IProductDao {

	@PersistenceContext	
	private EntityManager entityManager;	
	
	@Override
	public void addProduct(ProductEntity product) {
		entityManager.persist(product);
		
	}

	@Override
	public ProductEntity getProductById(int productId) {
		return entityManager.find(ProductEntity.class, productId);
	}

	@Override
	public void updateProduct(ProductEntity updatedProduct) {
		ProductEntity producToUpdate = getProductById(updatedProduct.getProductId());
		producToUpdate.setName(updatedProduct.getName());;
		producToUpdate.setDescription(updatedProduct.getDescription());
		entityManager.flush();
		
	}

	@Override
	public void deleteProduct(int productId) {
		entityManager.remove(getProductById(productId));		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ProductEntity> getAllProducts() {
		String query = "FROM product as prod ORDER BY prod.productId";
		return (List<ProductEntity>) entityManager.createQuery(query).getResultList();
	}

	@Override
	public boolean productAvailable(int productId) {
		
		ProductEntity productToCheck = getProductById(productId);
		return (productToCheck.getAvailableArticles() > 0);
		
	}
	

}
