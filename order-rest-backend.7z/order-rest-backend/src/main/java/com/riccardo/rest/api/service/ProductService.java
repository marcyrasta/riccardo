package com.riccardo.rest.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.riccardo.rest.api.dao.IProductDao;
import com.riccardo.rest.api.entity.ProductEntity;

@Service
public class ProductService implements IProductService {

	@Autowired
	private IProductDao productDAO;
	
	@Override
	public void addProduct(ProductEntity product) {
		productDAO.updateProduct(product);
		
	}

	@Override
	public ProductEntity getProductById(int productId) {
		ProductEntity product = productDAO.getProductById(productId);
		return  product;
	}

	@Override
	public void updateProduct(ProductEntity product) {
		productDAO.updateProduct(product);
		
	}

	@Override
	public void deleteProduct(int productId) {
		productDAO.deleteProduct(productId);
		
	}

	@Override
	public List<ProductEntity> getAllProducts() {
		return productDAO.getAllProducts();
	}

	@Override
	public boolean productAvailable(int productId) {
		return productDAO.productAvailable(productId);
	}

}
