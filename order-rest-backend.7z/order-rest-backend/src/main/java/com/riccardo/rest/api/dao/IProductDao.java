/**
 * 
 */
package com.riccardo.rest.api.dao;
import java.util.List;

import com.riccardo.rest.api.entity.ProductEntity;

/**
 * @author m_de
 *
 */
public interface IProductDao {
	
	//Create
    void addProduct(ProductEntity product);
    
    //read
    ProductEntity getProductById(int productId);
    
    //update
    void updateProduct(ProductEntity product);
    
    
    //delete
    void deleteProduct(int productId);
    
   
    List<ProductEntity> getAllProducts();
	
    boolean productAvailable(int productId);

}
