package com.riccardo.rest.api.mapper;

import org.springframework.stereotype.Component;

import com.riccardo.rest.api.domain.Product;
import com.riccardo.rest.api.entity.ProductEntity;

@Component
public class EntityToDomainMapping extends EntityToDomainAbstract<ProductEntity, Product>{

	@Override
	public Product toDomain(ProductEntity productEntity) {
		
		Product product = new Product(productEntity);
		
		return product;
	}

}
