package com.riccardo.rest.api.domain;

import com.riccardo.rest.api.entity.ProductEntity;

public class Product {
	
	private int id;
	//product name
	private String name;
	
	//product short description
	private String description;
	
	
	//Number of articles available for the current product
	private Integer availableArticles;
	
	//is there any article available?
	@SuppressWarnings("unused")
	private boolean isAvailable;
	
	
	public Product(ProductEntity productEntity) {
		id = productEntity.getProductId();
		description = productEntity.getDescription();
		name = productEntity.getName();
		availableArticles = productEntity.getAvailableArticles();
		isAvailable = isAvailable();
	}
	
	
	public int getId() {
		return id;
	}
	
	
	public void setId(int id) {
		this.id = id;
	}
	

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the availableArticles
	 */
	public Integer getAvailableArticles() {
		return availableArticles;
	}

	/**
	 * @param availableArticles the availableArticles to set
	 */
	public void setAvailableArticles(Integer availableArticles) {
		this.availableArticles = availableArticles;
	}

	/**
	 * returns true if there is at least one available article,
	 * false otherwise
	 * 
	 * @return the isAvailable
	 */
	public boolean isAvailable() {
		
		return (getAvailableArticles() > 0);
		
	}

	/**
	 * @param isAvailable the isAvailable to set
	 */
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	
	

	
}
