/**
 * 
 */
package com.riccardo.rest.api.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author m_de
 *
 */
@Entity
@Table(name="product")
public class ProductEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="idProduct")
        private int idProduct;  
	
	@Column(name="name")
        private String name;
	
	@Column(name="description")	
	private String description;
	
	@Column(name="availableArticles")	
	private Integer availableArticles;
	
	public int getProductId() {
		return idProduct;
	}
	public void setProductId(int idProduct) {
		this.idProduct = idProduct;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getAvailableArticles() {
		return availableArticles;
	}
	public void setAvailableArticles(Integer availableArticles) {
		this.availableArticles = availableArticles;
	}
	
	
}
