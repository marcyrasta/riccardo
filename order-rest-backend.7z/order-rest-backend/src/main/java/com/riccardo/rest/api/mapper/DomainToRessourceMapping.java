package com.riccardo.rest.api.mapper;

import org.springframework.stereotype.Component;

import com.riccardo.rest.api.domain.Product;
import com.riccardo.rest.api.resource.ProductResource;

@Component
public class DomainToRessourceMapping extends DomainToRessourceAbstract<Product, ProductResource> {
	

	@Override
	public ProductResource toResource(Product product) {
		
		ProductResource productResource = new ProductResource(product);
		
		return productResource;
	}
}
