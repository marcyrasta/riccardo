package com.riccardo.rest.api.mapper;

import org.springframework.stereotype.Component;

import com.riccardo.rest.api.domain.Product;
import com.riccardo.rest.api.entity.ProductEntity;

@Component
public class DomainToEntityMapping extends DomainToEntityAbstract <Product, ProductEntity>{

	@Override
	public ProductEntity toEntity(Product productDomain) {
    
		ProductEntity productEntity = new ProductEntity();
		productEntity.setProductId(productDomain.getId());
		productEntity.setAvailableArticles(productDomain.getAvailableArticles());
		productEntity.setDescription(productDomain.getDescription());
		productEntity.setName(productDomain.getName());
		return productEntity;
	}

}
