package com.riccardo.rest.api.repository;

import org.springframework.stereotype.Repository;

import com.riccardo.rest.api.domain.Product;

@Repository
public class OrderRepository {
/*extends InMemoryRepository<Product> {

	/*protected void updateIfExists(Product original, Product updated) {
		original.setDescription(updated.getDescription());
		original.setCost(updated.getCost());
		original.setDescription(updated.getDescription());
	}*/
}
