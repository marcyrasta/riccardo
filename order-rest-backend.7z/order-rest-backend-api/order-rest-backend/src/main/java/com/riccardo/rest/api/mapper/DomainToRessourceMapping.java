package com.riccardo.rest.api.mapper;

import org.springframework.stereotype.Component;

import com.riccardo.rest.api.domain.ProductDTO;
import com.riccardo.rest.api.resource.ProductResource;

@Component
public class DomainToRessourceMapping extends DomainToRessourceAbstract<ProductDTO, ProductResource> {
	

	@Override
	public ProductResource toResource(ProductDTO product) {
		
		ProductResource productResource = new ProductResource(product);
		
		return productResource;
	}
}
