/*
 * ----------------------------------------------
 * Projet ou Module : order-rest-backend
 * Nom de la classe : OrderRestBackendApplication.java
 * Date de création : 22 févr. 2018
 * Heure de création : 21:38:31
 * Package : com.riccardo.rest.api
 * Auteur : Marcel Deussom
 * Copyright © 2018 - All rights reserved.
 * ----------------------------------------------
 */

package com.riccardo.rest.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.riccardo.rest.api.config.AppConfig;

/**
 * @author Marcel
 */
@SpringBootApplication
@Import(AppConfig.class)
public class ProductRestBackendApplication {
	
	/**
	 * @param args
	 *            main
	 *            void
	 */
	public static void main(String ... args) {

		//
		SpringApplication.run(ProductRestBackendApplication.class, args);
		
	}
	
}
