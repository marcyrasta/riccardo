
package com.riccardo.rest.api.mapper;

import org.springframework.stereotype.Component;

import com.riccardo.rest.api.domain.ProductDTO;
import com.riccardo.rest.api.entity.ProductEntity;

/**
 * @author Marcel
 */
@Component
public class DomainToEntityMapping extends DomainToEntityAbstract<ProductDTO, ProductEntity> {
	
	@Override
	public ProductEntity toEntity(ProductDTO productDomain) {
		
		ProductEntity productEntity = new ProductEntity();
		productEntity.setProductId(Integer.valueOf(productDomain.getId()));
		productEntity.setAvailableArticles(productDomain.getAvailableArticles());
		productEntity.setDescription(productDomain.getDescription());
		productEntity.setName(productDomain.getName());
		return productEntity;
	}
	
}
