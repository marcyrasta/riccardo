/*
 * ----------------------------------------------
 * Projet ou Module : order-rest-backend
 * Nom de la classe : package-info.java
 * Date de création : 22 févr. 2018
 * Heure de création : 21:47:28
 * Package : com.riccardo.rest.api.config
 * Auteur : Marcel Deussom
 * Copyright © 2018 - All rights reserved.
 * ----------------------------------------------
 */
/**
 * Order -rest-backend config package
 * 
 * @author Marcel
 */

package com.riccardo.rest.api.config;
