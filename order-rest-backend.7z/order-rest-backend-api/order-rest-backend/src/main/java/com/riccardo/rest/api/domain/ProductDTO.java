
package com.riccardo.rest.api.domain;

import com.riccardo.rest.api.entity.ProductEntity;
import com.riccardo.rest.api.resource.ProductResource;

/**
 * @author Marcel
 */
public class ProductDTO {

	private Integer id;
	// product name
	private String name;

	// product short description
	private String description;
	
	// Number of articles available for the current product
	private Integer availableArticles;

	// is there any article available?
	@SuppressWarnings("unused")
	private boolean isAvailable;
	
	/**
	 * Instantiates a new product dto.
	 *
	 * @param productEntity
	 *            the product entity
	 */
	public ProductDTO(ProductEntity productEntity) {
		this.id = productEntity.getProductId();
		this.description = productEntity.getDescription();
		this.name = productEntity.getName();
		this.availableArticles = productEntity.getAvailableArticles();
		this.isAvailable = isAvailable();
	}
	
	
	public ProductDTO() {
        super();
    }
	/**
	 * Instantiates a new product dto.
	 *
	 * @param productResource
	 *            the product entity
	 */
	public ProductDTO(ProductResource productResource) {
		this.id = productResource.getResourceId();
		this.description = productResource.getDescription();
		this.name = productResource.getName();
		this.availableArticles = productResource.getAvailableArticles();
		this.isAvailable = isAvailable();
	}
	
	public Integer getId() {
		return this.id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}
	
	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the availableArticles
	 */
	public Integer getAvailableArticles() {
		return this.availableArticles;
	}
	
	/**
	 * @param availableArticles
	 *            the availableArticles to set
	 */
	public void setAvailableArticles(Integer availableArticles) {
		this.availableArticles = availableArticles;
	}
	
	/**
	 * returns true if there is at least one available article,
	 * false otherwise
	 *
	 * @return the isAvailable
	 */
	public boolean isAvailable() {

		return (getAvailableArticles() > 0);

	}
	
	/**
	 * @param isAvailable
	 *            the isAvailable to set
	 */
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	
}
