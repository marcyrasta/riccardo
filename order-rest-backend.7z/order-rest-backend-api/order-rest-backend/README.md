# Stock Management REST API ![CI Status](https://travis-ci.org/albanoj2/order-rest-backend.svg?branch=master)

Builds a RESTful web service using Spring MVC and Java.
This stock management service, is able to get a single product, get all products, as well as creating a new product, delete a product, and update a product. 

 

## REST Endpoints

The following REST endpoints are available upon deployment of the stock management system:

| HTTP Verb        | URL           | Description  | Status Codes |
| ------------- |-------------|:-----| ----|
| `GET` | `http://localhost:8080/product` | Obtains a list of all existing products | <ul><li>`200 OK`</li></ul> |
| `GET` | `http://localhost:8080/product/{id}` | Obtains the product with id {id} | <ul><li>`200 OK` if order exists</li><li>`404 Not Found` if the produrct does not exist</li></ul> |
| `POST` | `http://localhost:8080/product` | Creates a new product based on the content of the request body | <ul><li>`201 Created` if the product was successfully created</li></ul> |
| `PUT` | `http://localhost:8080/product/{id}` | Updated an existing product with the data contained in the request body | <ul><li>`200 OK` if the product was succesfully updated</li><li>`404 Not Found` if the product does not exist</li></ul> |
| `DELETE` | `http://localhost:8080/product/{id}` | Deletes an existing product that corresponds to the supplied order ID | <ul><li>`203 No Content` if the product was succesfully deleted</li><li>`404 Not Found` if the product does not exist</li></ul> |
