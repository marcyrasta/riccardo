package com.riccardo.rest.api.resource;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.riccardo.rest.api.domain.ProductDTO;

public class ProductResource extends ResourceSupport {

	private final int id;
	private final String description;
	private final String name;
	private final boolean isAvailable;
	private final int availableArticles;
	
	public ProductResource(ProductDTO product) {
		id = product.getId();
		description = product.getDescription();
		name=product.getName();
		availableArticles=product.getAvailableArticles();
		isAvailable = product.isAvailable();
	}

	@JsonProperty("id")
	public int getResourceId() {
		return id;
	}
	
	public String getDescription() {
		return description;
	}


	public boolean isAvailable() {
		return isAvailable;
	}


	public String getName() {
		return name;
	}

	public int getAvailableArticles() {
		return availableArticles;
	}
	
	
}
