
package com.riccardo.rest.api.mapper;

import java.util.Collection;
import java.util.stream.Collectors;

/**
 * @author Marcel
 * @param <DomainType>
 * @param <EntityType>
 */
public abstract class DomainToEntityAbstract<DomainType, EntityType> {
	
	public abstract EntityType toEntity(DomainType domainObject);
	
	public Collection<EntityType> toDomainCollection(Collection<DomainType> domainObject) {
		return domainObject.stream().map(o -> toEntity(o)).collect(Collectors.toList());
	}
}
