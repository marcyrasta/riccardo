
package com.riccardo.rest.api.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.riccardo.rest.api.entity.ProductEntity;
import com.riccardo.rest.api.repository.ProductRepository;

/**
 * @author Marcel
 */
@Component
public class ProductService {
	
	@Autowired
	private ProductRepository productDAO;

	/**
	 * Adds the product.
	 *
	 * @param product
	 *            addProduct
	 *            void
	 * @return the product entity
	 */
	public ProductEntity addProduct(ProductEntity product) {
		return this.productDAO.save(product);

	}
	
	/**
	 * @param productId
	 * @return
	 *         getProductById
	 *         ProductEntity
	 */
	public ProductEntity getProductById(Integer productId) {
		ProductEntity product = this.productDAO.findOne(productId);
		return product;
	}
	
	/**
	 * @param product
	 * @return
	 *         updateProduct
	 *         ProductEntity
	 */
	public ProductEntity updateProduct(ProductEntity product) {
		ProductEntity reponse = this.productDAO.saveAndFlush(product);
		return reponse;
	}
	
	/**
	 * @param productId
	 *            deleteProduct
	 *            void
	 */
	public void deleteProduct(Integer productId) {
		this.productDAO.delete(productId);

	}
	
	/**
	 * @return
	 *         getAllProducts
	 *         List<ProductEntity>
	 */
	public Collection<ProductEntity> getAllProducts() {
		return this.productDAO.findAll();
	}
	
	/**
	 * @param productId
	 * @return
	 *         productAvailable
	 *         boolean
	 */
	public boolean productAvailable(Integer productId) {
		return this.productDAO.exists(productId);
	}
	
}
