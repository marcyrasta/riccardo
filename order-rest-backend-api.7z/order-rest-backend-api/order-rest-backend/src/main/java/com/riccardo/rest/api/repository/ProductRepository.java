/*
 * ----------------------------------------------
 * Projet ou Module : order-rest-backend
 * Nom de la classe : ProductRepository.java
 * Date de création : 22 févr. 2018
 * Heure de création : 22:21:51
 * Package : com.riccardo.rest.api.repository
 * Auteur : Vincent Otchoun
 * Copyright © 2018 - All rights reserved.
 * ----------------------------------------------
 */

package com.riccardo.rest.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.riccardo.rest.api.entity.ProductEntity;

/**
 * @author Marcel
 */
@Repository
public interface ProductRepository extends JpaRepository<ProductEntity, Integer> {
	//
}
