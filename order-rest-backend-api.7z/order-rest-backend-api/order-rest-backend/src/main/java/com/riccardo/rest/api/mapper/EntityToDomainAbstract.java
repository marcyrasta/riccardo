package com.riccardo.rest.api.mapper;

import java.util.Collection;
import java.util.stream.Collectors;

public abstract class EntityToDomainAbstract <EntityType, DomainType> {

	public abstract DomainType toDomain(EntityType entityObject);

	public Collection<DomainType> toDomainCollection(Collection<EntityType> entityObject) {
		return entityObject.stream().map(o -> toDomain(o)).collect(Collectors.toList());
	}
	
}
