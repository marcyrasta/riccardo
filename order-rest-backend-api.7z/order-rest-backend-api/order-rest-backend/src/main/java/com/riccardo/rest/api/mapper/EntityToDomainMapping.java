package com.riccardo.rest.api.mapper;

import org.springframework.stereotype.Component;

import com.riccardo.rest.api.domain.ProductDTO;
import com.riccardo.rest.api.entity.ProductEntity;

@Component
public class EntityToDomainMapping extends EntityToDomainAbstract<ProductEntity, ProductDTO>{

	@Override
	public ProductDTO toDomain(ProductEntity productEntity) {
		
		ProductDTO product = new ProductDTO(productEntity);
		
		return product;
	}

}
