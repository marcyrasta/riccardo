/*
 * ----------------------------------------------
 * Projet ou Module : order-rest-backend
 * Nom de la classe : AppConfig.java
 * Date de création : 22 févr. 2018
 * Heure de création : 21:48:33
 * Package : com.riccardo.rest.api.config
 * Auteur : Marcel Deussom
 * Copyright © 2018 - All rights reserved.
 * ----------------------------------------------
 */

package com.riccardo.rest.api.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;

/**
 * @author Marcel
 */
@Configuration
@PropertySource(value = { "classpath:application-dev.properties" })
@ComponentScan(basePackages = { "com.riccardo.rest.api" })
@EntityScan("com.riccardo.rest.api.entity")
@EnableJpaRepositories(basePackages = "com.riccardo.rest.api.repository")
@ActiveProfiles("dev")
public class AppConfig {
	//

}
