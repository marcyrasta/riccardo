
package com.riccardo.rest.api.controller;

import java.util.Collection;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.ExposesResourceFor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.riccardo.rest.api.domain.ProductDTO;
import com.riccardo.rest.api.entity.ProductEntity;
import com.riccardo.rest.api.mapper.DomainToEntityMapping;
import com.riccardo.rest.api.mapper.DomainToRessourceMapping;
import com.riccardo.rest.api.mapper.EntityToDomainMapping;
import com.riccardo.rest.api.resource.ProductResource;
import com.riccardo.rest.api.service.ProductService;

/**
 * @author Marcel
 */
@RestController
@ExposesResourceFor(ProductDTO.class)
@RequestMapping(value = "/product", produces = "application/json")
public class ProductController {

	@Autowired
	private ProductService productService;

	@Autowired
	private DomainToRessourceMapping domainToRessourceMapping;
	
	@Autowired
	private EntityToDomainMapping entityTODomainMapping;

	@Autowired
	private DomainToEntityMapping domainToEntityMapping;

	private static Logger logger = Logger.getLogger(ProductController.class);

	/**
	 * @return
	 *         findAllProducts
	 *         ResponseEntity<Collection<ProductResource>>
	 */
	@GetMapping("/findAllProducts")
	public ResponseEntity<Collection<ProductResource>> findAllProducts() {

		logger.info("\n#### findAllProducts starts...#####");
		Collection<ProductEntity> productentities = null;
		Collection<ProductResource> productRessources = null;
		try {
			// repository.findAll();
			productentities = this.productService.getAllProducts();

			Collection<ProductDTO> products = this.entityTODomainMapping.toDomainCollection(productentities);
			productRessources = this.domainToRessourceMapping.toResourceCollection(products);
		}catch(Exception e) {
			logger.debug("An error occured while retrieving all products " + e.getMessage());
		}

		if(productentities!=null  && !productentities.isEmpty()) {
			return new ResponseEntity<Collection<ProductResource>>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<Collection<ProductResource>>(productRessources, HttpStatus.OK);
		}
		
	}

	/**
	 * @param product
	 * @param builder
	 * @return
	 *         addProduct
	 *         ResponseEntity<Void>
	 */
	// @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
	@PostMapping("/addProduct")
	public ResponseEntity<ProductResource> addProduct(@RequestBody ProductDTO product) {

        ProductResource newProductRessource = null;
        ProductEntity newProductEntity = null;
		try {
			
			newProductEntity = this.productService.addProduct(this.domainToEntityMapping.toEntity(product));
			ProductDTO newProductDTO = this.entityTODomainMapping.toDomain(newProductEntity);
			newProductRessource = this.domainToRessourceMapping.toResource(newProductDTO);
					
		} catch (Exception e) {
			logger.debug("An error occured while adding a new product " + e.getMessage());
		}

		if(newProductEntity!=null) {
			return new ResponseEntity<ProductResource>(newProductRessource, HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_MODIFIED);
		}
		
	}

	/**
	 * @param id
	 * @return
	 *         findProductById
	 *         ResponseEntity<ProductResource>
	 */
	// @RequestMapping(value = "/{id}", method = RequestMethod.GET)
	@GetMapping("findProductById/{id}")
	public ResponseEntity<ProductResource> findProductById(@PathVariable int id) {

		ProductResource productRessource = null;

		try {

			ProductEntity productEntity = this.productService.getProductById(id);
			ProductDTO productDomain = this.entityTODomainMapping.toDomain(productEntity);
			productRessource = this.domainToRessourceMapping.toResource(productDomain);
			
		} catch (Exception e) {
			logger.debug("An error occured while retrieving the product with id " +id + " with the following errormessage" + e.getMessage());
		}

		if (productRessource != null) {
			return new ResponseEntity<ProductResource>(productRessource, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * @param id
	 * @return
	 *         deleteProduct
	 *         ResponseEntity<Void>
	 */
	// @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	@PostMapping("/delete/{id}")
	public ResponseEntity<Void> deleteProduct(@PathVariable int id) {

		HttpStatus responseStatus = null;
		try {

			// check if the product exists before deleting
			if (this.productService.getProductById(id) != null) {

				this.productService.deleteProduct(id);
				responseStatus = HttpStatus.NO_CONTENT;

			} else {
				responseStatus = HttpStatus.NOT_FOUND;
			}

		} catch (Exception e) {
			logger.debug("An error occured while deleting the product with id " +id + " with the following error message" + e.getMessage());
		}

		return new ResponseEntity<>(responseStatus);
	}

	/**
	 * @param updatedProduct
	 * @return
	 *         updateOrder
	 *         ResponseEntity<ProductResource>
	 */
	// @RequestMapping(value = "/{id}", method = RequestMethod.PUT, consumes = "application/json")
	@PostMapping("/updateOrder/")
	public ResponseEntity<ProductResource> updateOrder(@RequestBody ProductDTO updatedProduct) {

		HttpStatus responseStatus = null;
		ProductResource updatedProductRessource = null;
		try {

			// check if the product exists before deleting
			if (this.productService.getProductById(updatedProduct.getId()) != null) {
				ProductEntity productEntity = this.domainToEntityMapping.toEntity(updatedProduct);
				this.productService.updateProduct(productEntity);
				updatedProductRessource = this.domainToRessourceMapping.toResource(updatedProduct);

				responseStatus = HttpStatus.OK;
			} else {
				responseStatus = HttpStatus.NOT_FOUND;
			}

		} catch (Exception e) {
			logger.debug("An error occured while updating the product with the following error message" +e.getMessage());
		}

		return new ResponseEntity<ProductResource>(updatedProductRessource, responseStatus);
		
	}
}
