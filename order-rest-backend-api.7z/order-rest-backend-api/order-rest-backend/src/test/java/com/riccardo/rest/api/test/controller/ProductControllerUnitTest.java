package com.riccardo.rest.api.test.controller;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.riccardo.rest.api.domain.ProductDTO;
import com.riccardo.rest.api.entity.ProductEntity;
import com.riccardo.rest.api.repository.ProductRepository;
import com.riccardo.rest.api.service.ProductService;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;




@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ProductControllerUnitTest {
	
	@Autowired
	private ProductRepository repository;
	
	@Autowired
	private MockMvc mockMvc;
	
    @Test
	public void testFindAllProducts() throws Exception {
		 
    	ProductService productServiceMock = mock(ProductService.class);	
    	List<ProductEntity> expectedResult = new ArrayList<ProductEntity>();
    	
    	ProductEntity pr1 = new ProductEntity();
    	pr1.setAvailableArticles(2);
    	pr1.setDescription("first citroen model");
    	pr1.setName("citroen c4");
    	pr1.setProductId(1);
    	
    	ProductEntity pr2 = new ProductEntity();
    	pr2.setAvailableArticles(2);
    	pr2.setDescription("citroen for familly");
    	pr2.setName("citroen c4 picasso");
    	pr2.setProductId(2);
    	
    	ProductEntity pr3 = new ProductEntity();
    	pr3.setAvailableArticles(2);
    	pr3.setDescription("citroen new model");
    	pr3.setName("citroen c4 picasso");
    	pr3.setProductId(3);
    	
    	expectedResult.add(pr1);
    	expectedResult.add(pr2);
    	expectedResult.add(pr3);
    	
    	when(productServiceMock.getAllProducts()).thenReturn(expectedResult);
    	
    	this.mockMvc.perform(get("/product/findAllProducts")

		        .contentType(MediaType.APPLICATION_JSON))
				
		        .andExpect(status().isOk())
				
		        .andDo(print()
		        );
    	
    	
    }
    
    @Test
  	public void testAddProduct() throws Exception {
  		 //TODO  	
   }
    
    @Test
  	public void testFindProductById() throws Exception {
    	//TODO	
   }
    
    @Test
  	public void testDeleteProduct() throws Exception {
    	//TODO   	
   }
    
}
