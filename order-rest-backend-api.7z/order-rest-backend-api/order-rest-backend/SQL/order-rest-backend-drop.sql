drop table if exists product
