create table product (id_product integer not null auto_increment, available_articles integer, description varchar(255), name varchar(255), primary key (id_product))
